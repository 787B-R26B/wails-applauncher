import sys
from calculator import add

if len(sys.argv) != 3:
    print("Usage: python main.py <num1> <num2>")
    sys.exit(1)

try:
    num1 = float(sys.argv[1])
    num2 = float(sys.argv[2])
    result = add(num1, num2)
    print(f"The sum is: {result}")
except ValueError:
    print("Please provide two numbers.")
    sys.exit(1)
