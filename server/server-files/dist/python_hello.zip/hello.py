import sys
import platform

print("Hello from Python!")
print(f"Python version: {sys.version}")
print(f"Platform: {platform.system()}")
